import { expect } from "@playwright/test";

export class ZipCodePage {
  page;
  constructor(page) {
    this.page = page;
  }

  async enterZipCode() {
    const link = this.page.getByRole("link", {
      name: "ingresa tu",
    });

    link.click();

    const frameCP = this.page.frameLocator(".modal-iframe-cp iframe");

    const textLink = frameCP.getByRole("textbox", { name: /Código postal/i });
    textLink.fill("95096");

    const button = frameCP.getByRole("button", { name: /Usar/i });

    await button.click();

    const zcLink = this.page.getByRole("link", { name: "95096" });
    expect(zcLink).toBeVisible();
  }
}
